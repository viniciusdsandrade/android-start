package com.example.imc_22300_22333

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var edtAltura: EditText
    private lateinit var edtPeso: EditText
    private lateinit var txtResp: TextView

    companion object {
        private const val LIMITE_IMC_SUPERIOR = 29.9
        private const val LIMITE_IMC_INFERIOR = 18.5
        private const val LIMITE_IMC_IDEAL_SUPERIOR = 25.0
        private const val LIMITE_IMC_IDEAL_INFERIOR = 18.6
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initializeViews()

        val btnExec = findViewById<Button>(R.id.btnExec)
        btnExec.setOnClickListener {
            calcularIMC()
        }
    }

    private fun initializeViews() {
        edtAltura = findViewById(R.id.EdtTxAlt)
        edtPeso = findViewById(R.id.edtTxPeso)
        txtResp = findViewById(R.id.txtResp)
    }

    private fun calcularIMC() {
        val pesoStr = edtPeso.text.toString()
        val alturaStr = edtAltura.text.toString()

        if (pesoStr.isEmpty() || alturaStr.isEmpty()) {
            exibirErro("Por favor, preencha todos os campos corretamente.")
            return
        }

        try {
            val peso = pesoStr.toDouble()
            var altura = alturaStr.toDouble()

            if (peso <= 0 || altura <= 0 || altura > 272 || peso > 595) {
                exibirErro("Por favor, insira valores válidos para peso e altura.")
                return
            }

            altura /= 100
            val imc = peso / (altura * altura)
            exibirResultado(imc)
        } catch (e: NumberFormatException) {
            exibirErro("Por favor, insira valores numéricos válidos para peso e altura.")
        }
    }

    private fun exibirResultado(imc: Double) {
        val mensagem = "Seu IMC é: $imc"
        val cor = when {
            imc > LIMITE_IMC_SUPERIOR || imc < LIMITE_IMC_INFERIOR -> Color.RED
            imc <= LIMITE_IMC_IDEAL_INFERIOR || imc >= LIMITE_IMC_IDEAL_SUPERIOR -> Color.rgb(
                255,
                160,
                0
            )

            else -> Color.GREEN
        }

        txtResp.setTextColor(cor)
        txtResp.text = mensagem
        txtResp.visibility = View.VISIBLE
    }

    private fun exibirErro(mensagem: String) {
        Toast.makeText(this, mensagem, Toast.LENGTH_SHORT).show()
    }
}